INSERT INTO public.opd (first_name,last_name,symptoms,med1,quantity_1,med2,quantity_2,med3,quantity_3,med4,quantity_4,med5,quantity_5,med6,quantity_6,date_time) VALUES
	 ('Shreyash','Gajbhiye','eda','Dolo',23,'-',0,'-',0,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-27 00:33:09.808328'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'null',23,'-',34,'null',45,'null',5676,'null',67,'2023-03-27 00:37:50.278174'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'abc',23,'-',34,'xyz',45,'Dolo',5676,'abc',67,'2023-03-27 00:39:01.303654'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'d',23,'-',34,'xyz',45,'Dolo',5676,'abc',67,'2023-03-27 00:40:13.299194'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'Dolo',23,'-',34,'do',45,'Dolo',5676,'abc',67,'2023-03-27 00:40:43.022871'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'Dolo',23,'-',34,'Dolo',45,'Dolo',5676,'Dolo',67,'2023-03-27 00:40:57.156149'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'Dolo',23,'-',34,'Dolo',45,'Dolo',5676,'Dolo',67,'2023-03-27 00:43:01.171218'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'Dolo',23,'null',34,'Dolo',45,'Dolo',5676,'Dolo',67,'2023-03-27 00:43:34.694801'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'Dolo',23,'abc',34,'Dolo',45,'Dolo',5676,'Dolo',67,'2023-03-27 00:44:58.884272'),
	 ('Shreyash','Gajbhiye','qsdf saf','Dolo',13,'Dolo',23,'iuyu',34,'Dolo',45,'Dolo',5676,'Dolo',67,'2023-03-27 00:45:07.603206');
INSERT INTO public.opd (first_name,last_name,symptoms,med1,quantity_1,med2,quantity_2,med3,quantity_3,med4,quantity_4,med5,quantity_5,med6,quantity_6,date_time) VALUES
	 ('Shreyash','Gajbhiye','w2','Dolo',1,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-29 23:46:40.319371'),
	 ('Shreyash','Gajbhiye','sad','Dolo',1,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-29 23:50:20.978707'),
	 ('Soham','Ambarte','sq','Dolo',5,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-29 23:54:10.316049'),
	 ('Soham','Ambarte','w23','Dolo',50,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-30 00:01:31.000107'),
	 ('Soham','Ambarte','eee','Dolo',5,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-30 00:04:48.208323'),
	 ('Soham','Ambarte','nj','Dolo',5,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-30 00:07:10.928958'),
	 ('Shreyash','Gajbhiye','rrr','Dolo',5,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-30 00:07:53.994562'),
	 ('Soham','Ambarte','jhvvj iuiuh ','Dolo',5,'-',0,'-',0,'-',0,'-',0,'-',0,'2023-03-30 19:27:25.545556'),
	 ('Soham','Ambarte','knlj','Supra',5,'Supra',6,'Supra',9,'Supra',9,'Supra',9,'Supra',9,'2023-03-31 21:42:43.453716'),
	 ('Soham','Ambarte','knlj','Supra',5,'Supra',6,'Supra',9,'Supra',9,'Supra',9,'Supra',9,'2023-03-31 21:55:01.590276');
