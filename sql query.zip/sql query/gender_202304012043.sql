INSERT INTO public.gender (gender) VALUES
	 ('Male'),
	 ('Female'),
	 ('Other');
