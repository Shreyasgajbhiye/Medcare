INSERT INTO public.patient_name ("name") VALUES
	 ('Shreyash Gajbhiye'),
	 ('Aditya  Thakre'),
	 ('Soham Ambarte');
