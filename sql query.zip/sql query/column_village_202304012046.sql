INSERT INTO public.column_village ("name") VALUES
	 ('village_id'),
	 ('village_name'),
	 ('village_code');
