INSERT INTO public.family_col ("name") VALUES
	 ('family_id'),
	 ('village'),
	 ('address');
