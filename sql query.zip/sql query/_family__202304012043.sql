INSERT INTO public."family" (family_id,village,address) VALUES
	 ('1','Chandrapur','ij'),
	 ('1','Chandrapur','xyz'),
	 ('1','Chandrapur','swa'),
	 ('1','Chandrapur','swa'),
	 ('1','Akola','xyz'),
	 ('1','Akola','xyz'),
	 ('50','Eva','yhguyhg ,ouho');
