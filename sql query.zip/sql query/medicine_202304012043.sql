INSERT INTO public.medicine (medicine_id,medicine_name,quantity,expiry_date,insert_date) VALUES
	 ('1','Dolo',200,'2023-03-17','2023-03-14 20:36:20.097291'),
	 ('25','Vicks',30,'2023-03-21','2023-03-30 19:40:52.006292'),
	 ('25','Supra',8671,'2023-03-04','2023-03-29 14:03:27.824915');
