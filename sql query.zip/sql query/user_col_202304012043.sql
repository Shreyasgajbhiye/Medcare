INSERT INTO public.user_col ("name") VALUES
	 ('user_id'),
	 ('first_name'),
	 ('last_name'),
	 ('family_id'),
	 ('dob'),
	 ('gender'),
	 ('mobile_no'),
	 ('blood_grp'),
	 ('email');
