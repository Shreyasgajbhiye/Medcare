INSERT INTO public.etc (etc_name,quantity,insert_date) VALUES
	 ('xyz',3,'2023-03-14 21:55:22.685969');
