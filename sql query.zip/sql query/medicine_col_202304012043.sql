INSERT INTO public.medicine_col ("name") VALUES
	 ('medicine_id'),
	 ('medicine_name'),
	 ('expiry_date'),
	 ('insert_date'),
	 ('quantity');
