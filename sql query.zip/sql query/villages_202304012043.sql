INSERT INTO public.villages (village_id,village_name,village_code) VALUES
	 ('ER','Eva','98765'),
	 ('100','Amravati','444608');
