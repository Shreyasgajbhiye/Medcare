INSERT INTO public.people (user_id,first_name,last_name,family_id,gender,dob,mobile_no,blood_grp,email) VALUES
	 ('2','jopk','pokpo','2','Male','2023-04-06','09870979','A','shreyashgajbhiye90@gmail.com'),
	 ('1','Shreyash','Gajbhiye','2','Male','2023-03-16','13123','A','dad'),
	 ('3','Aditya ','Thakre','65','Female','2023-03-09','8765436789','Q','kjgkjhk'),
	 ('10','Soham','Ambarte','10','Male','2023-03-21','098765','K','kjhgf');
