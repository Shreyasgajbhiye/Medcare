$(document).ready(function (){
   $("#addNew").click(function(e){
       var medicine= jQuery()
   }) 
});